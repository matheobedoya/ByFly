# ByFly: activar la actualización autónoma

Este paquete agrega el generador de PDF y un proceso programado al repositorio existente. No sustituye la web ni necesita comprar hosting en GoDaddy. La web conserva su despliegue actual en Cloudflare; el PDF se publica por separado en R2.

## 1. Corregir la hoja antes de publicar

Abrir `Filas_por_corregir.csv`. Hay 11 filas con producto pero sin SKU en la hoja publicada consultada el 10 de octubre de 2026. Asignar a cada variante un SKU único, sin reutilizar referencias. Confirmar las categorías vacías. Las posiciones corresponden al CSV publicado, contando el encabezado como fila 1; si la hoja cambió, localizar por nombre y tono.

La producción se detiene si encuentra productos sin SKU, referencias repetidas, precios inválidos, imágenes enlazadas que no se pueden descargar o texto fuera de la página. No omite estos productos silenciosamente. Las filas sin enlace de imagen sí aparecen con “Fotografía pendiente”. La hoja debe conservar las columnas SKU, nombre, categoria, precio_detal, precio_mayor, stock, disponible e imagen_url. Nuevo acepta Nuevo, sí, si, true o 1. También se admite badge=nuevo.

Los enlaces de Drive deben permitir la lectura pública de la foto; no es necesario hacer editable la carpeta. El programa usa la primera imagen disponible de cada familia y lo indica cuando hay varios tonos. No inventa fotografías ni tonos.

## 2. Subir el código a GitHub

En `matheobedoya/ByFly`, en la rama predeterminada, agregar:

- Toda la carpeta `catalog-automation`, incluidos assets y requirements.txt.
- El archivo `.github/workflows/catalog.yml`.

Se puede usar GitHub Desktop o el editor web. Si el cargador web no conserva `.github`, usar Add file > Create new file, escribir `.github/workflows/catalog.yml` y pegar exactamente el YAML incluido en este paquete. No subir la carpeta work, datos de costos, credenciales, ZIP completo o carpetas temporales. No cambiar wrangler.toml ni desconectar el dominio.

## 3. Crear las credenciales de R2

Cloudflare > R2 Object Storage > Manage R2 API Tokens > Create Account API Token.

- Nombre: ByFly catálogo automático.
- Permiso: Object Read & Write.
- Alcance: únicamente el bucket `byflycatalogo`.
- Guardar Access Key ID y Secret Access Key al crearlo. El secreto puede mostrarse una sola vez.
- Copiar el endpoint S3 de la cuenta, de la forma https://IDENTIFICADOR_DE_CUENTA.r2.cloudflarestorage.com.

No utilizar la contraseña de Cloudflare ni pegar claves en el chat o en archivos del repositorio.

## 4. Guardar tres secretos en GitHub

Repositorio > Settings > Secrets and variables > Actions > New repository secret.

| Nombre exacto | Valor |
|---|---|
| R2_ACCESS_KEY_ID | Access Key ID de R2 |
| R2_SECRET_ACCESS_KEY | Secret Access Key de R2 |
| R2_ENDPOINT | Endpoint S3 HTTPS, sin nombre de bucket al final |

Opcional: en Variables, crear CATALOG_SHEET_URL si se necesita otra hoja publicada. Si se deja vacía, se usa exactamente el CSV configurado en la web recibida. Verificar que corresponde a la hoja de trabajo de la clienta.

## 5. Activar y probar

1. Confirmar en R2 > byflycatalogo > Settings > Custom Domains que catalogo.byfly.com.co dejó de estar Initializing y figura activo.
2. GitHub > Actions > Actualizar catálogo ByFly > Run workflow. Primera ejecución: force desmarcado es suficiente.
3. Esperar a que el proceso termine en verde. Si falla, leer el paso que falló; el mensaje identifica el tipo de problema. Un fallo de la hoja requiere corregir la hoja, no desactivar las validaciones.
4. Abrir https://catalogo.byfly.com.co/ByFly_Catalogo.pdf y https://catalogo.byfly.com.co/actualizacion.json. El segundo muestra la fecha UTC, el número de referencias y la versión publicada.
5. Cambiar un precio de prueba en la hoja, ejecutar Run workflow y comprobar el nuevo PDF. Revertir el precio y repetir. Después verificar una ejecución programada.
6. Comprobar en móvil y PC portada, novedades en página 2, índice, varias fichas y el único enlace de WhatsApp en contacto.

El enlace solo funcionará después de un despliegue correcto; este paquete no ha instalado claves ni publicado en tu cuenta.

## Qué ocurre después

Cada hora, en el minuto 17, GitHub consulta la hoja y las imágenes de portada. Si cambiaron datos, fotos o el generador, crea y verifica un PDF nuevo y lo publica. También detecta cambios de imagen cuando se conserva el mismo ID de Drive mediante una miniatura descargada nuevamente. Las imágenes secundarias no mostradas no afectan la edición visual. El cron puede retrasarse y no representa una actualización instantánea. La clienta solo edita la hoja y mantiene disponibles los enlaces de fotos; no necesita abrir Cloudflare ni dejar un computador encendido.

La publicación conserva copias en versions/. El enlace estable apunta al PDF más reciente. Un PDF descargado previamente o enviado como adjunto por WhatsApp no cambia; compartir siempre el enlace. La fecha del PDF corresponde a la última generación, no a cada revisión sin cambios.

Activar GitHub Actions en la rama predeterminada. En repositorios públicos, GitHub puede desactivar cron tras 60 días sin actividad; revisar el estado periódicamente. Una instalación sin mantenimiento ni vigilancia no debe prometerse. Las notificaciones de fallos se consultan/configuran en GitHub. R2 y Actions están sujetos a cuotas de la cuenta; controlar consumo y almacenamiento de versions/. El proceso no borra versiones automáticamente.

Si existe una regla de caché de Cloudflare que fuerza almacenamiento, excluir /ByFly_Catalogo.pdf y /actualizacion.json para que el enlace estable refleje cambios. El programa envía encabezados de revalidación/no almacenamiento. No activar el URL de desarrollo público de R2: basta el dominio personalizado.

## Calidad y límites antes de entregar

- El PDF tiene un solo formato 4:5; no es una página responsive. Se ve mediante ajuste de página o zoom en móvil y PC. Un carrito operativo permanece en la web; el PDF lleva a contacto y al catálogo web.
- Categorías normalizadas por uso y reglas recuperadas del trabajo anterior. `revision.csv` de cada ejecución permite revisar SKU por SKU. La clasificación no sustituye el conocimiento comercial de la clienta.
- Logo oficial optimizado, imágenes contenidas sin recortar el producto, tipografías incrustadas y botones pequeños. Las fotos se consultan hasta 1600 px y se incrustan hasta 1400 px. La compresión JPEG de alta calidad reduce peso, pero no es matemáticamente sin pérdida ni puede mejorar fotos de baja resolución.
- La web recibida marca sus políticas como provisionales. El PDF mantiene un aviso de consulta; reemplazarlo por condiciones definitivas aprobadas antes de presentar la edición como catálogo comercial final.
- La vista previa local excluye únicamente las 11 filas sin SKU y no debe presentarse como catálogo completo. La automatización de producción no permite esa omisión.

## Ejecución local

Python 3.12:

    python -m pip install -r catalog-automation/requirements.txt
    python -m unittest discover -s catalog-automation -p 'test_*.py'
    python catalog-automation/sync.py --local-csv /ruta/hoja.csv

Esto valida y genera sin publicar. Producción usa los tres secretos indicados. `--force` fuerza regeneración y permite una reducción de más del 20% de referencias cuando es intencional; no permite SKU duplicados, filas incompletas o imágenes enlazadas inválidas.
